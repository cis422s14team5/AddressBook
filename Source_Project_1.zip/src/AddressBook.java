
/**
 * AddressBook is an address management program.
 */
public class AddressBook {
    /**
     * AddressBook method.
     * @param args is the command line arguments array.
     */
    public static void main(String[] args) {
        new AllBooks();
    }
}